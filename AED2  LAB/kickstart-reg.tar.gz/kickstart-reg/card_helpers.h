#ifndef _CARD_HELPERS_H_
#define _CARD_HELPERS_H_

#include "card.h"

void card_dump(card c);

#endif

